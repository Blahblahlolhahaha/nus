package cs2030s.fp;

public interface Transformer<T, U> {
  public U transform(T t);

}

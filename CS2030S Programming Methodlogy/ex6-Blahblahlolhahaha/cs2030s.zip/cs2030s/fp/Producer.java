package cs2030s.fp;

public interface Producer<T> {

  public T produce();

}

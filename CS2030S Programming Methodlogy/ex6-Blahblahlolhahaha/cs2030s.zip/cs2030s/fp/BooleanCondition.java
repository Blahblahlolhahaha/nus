package cs2030s.fp;

public interface BooleanCondition<T>         {

  boolean test(T t);
}
